Problem 1
javac *.java
java EfficiencyDriver

Problem 2
javac *.java
java PrintTreeTest

Problem 3
javac -cp * *.java
java -cp *;. org.junit.runner.JUnitCore Lab21Test
Lab21Answer.txt