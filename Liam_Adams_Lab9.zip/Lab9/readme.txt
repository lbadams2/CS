Problem 1
javac -cp * *.java
java -cp .;* org.junit.runner.JUnitCore BinarySearchTreeTest
** Answer in AnswerSheet.txt

Problem 2
javac -cp * *.java
java BSTArray_Driver
							3
						         \
							  18
							 /  \
							4    99
						         \   / \
						          5  /   \
							    50   101	 
							    / \
							   23  77
								\
								87
77 replaces 50


Problem 3
javac -cp * *.java
java -cp .;* org.junit.runner.JUnitCore BinarySearchTreeTest

Problem 4
javac -cp * *.java
java BSTArray_Driver