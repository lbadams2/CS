Problem 1:
javac -cp * *.java
java -cp .;* org.junit.runner.JUnitCore SinglyLinkedListTest

Problem 2:
run each class
comments in Answer7_6.java explaining each scenario

Problem 3:
java CS401LinkedList
