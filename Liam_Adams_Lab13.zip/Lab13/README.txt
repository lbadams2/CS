javac *.java
java CS401Graph breadth
java CS401Graph depth