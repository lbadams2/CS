Problem 1 Pascal's Triangle:
One source file, prints instructions to console

Problem 2 (Lab 10):
javac -cp * ArrayListExp.java ArrayListTest.java
java -cp .;* org.junit.runner.JUnitCore ArrayListTest

Problem 3 (Exercises in book):
6_4: Answer6_4.java, no dependencies
6_12: Answer6_12.java, no dependencies
6_13: Answer6_13.java, no dependencies

Problem 4 contains():
Implementation in CS401ArrayImpl.java



