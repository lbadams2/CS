Lab 7
windows command line:
javac FibonacciUser.java
java FibonacciUser


Lab 9
javac Permuatations.java
java Permutations
Will print all permutations for ABCD

