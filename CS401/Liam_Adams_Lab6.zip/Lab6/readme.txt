Problem 1
Run LinkedListTest.class

Problem 2
Run DblLinkedListTest.class

Problem 3
javac -cp * *.java
java -cp .;* org.junit.runner.JUnitCore StackTest

Problem 4
Run InfixToPostfix.class
Reads the infix expressions from infix.txt, the class expects the text file to be in the same directory 
