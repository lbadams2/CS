javac *.java
Problem 1: java Network span undirected
the name of the file is graph1.txt, hardcoded in the program

Problem 2: java Network path directed
for problem 2, the topology file is directedGraph.txt, start vertex A 

The format of my input file that describes the graph is:
source destination weight
each line is an edge with source vertex followed by a space, destination vertex followed by a space, and weight
if you pass undirected as an argument to the program it will create an edge going both ways between the vertices, otherwise it will create only the edges specified.