javac *.java
java SortTiming